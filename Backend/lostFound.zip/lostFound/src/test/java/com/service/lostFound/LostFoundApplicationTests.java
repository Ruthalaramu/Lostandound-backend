package com.service.lostFound;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostFoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
